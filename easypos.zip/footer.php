  <div class="panel-footer" style="text-align:right; margin-top:310px">
        		Powered by <a href="http://www.thetatech.org" target="_blank">Theta Technologies (pvt) Ltd </a>
   </div>