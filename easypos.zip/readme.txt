Easy POS sytem is an open source product developed by www.thetatech.org

Here are the steps to follow
1. create a new database with name 'easypos'
2. import DB file easypos.sql to newly created database
3. modify connection.php file accordingly
4. run the application and register yourself
5. login and use it

for any further assistance please contact me on my email nadeem@thetatech.org