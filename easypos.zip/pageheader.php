<div class="page-header" align="center" style="font-size:40px; color:#09F; font-family:Tahoma, Geneva, sans-serif; margin-top:-8px; background-image:url(background-header.jpg)">
    Easy POS System
</div>
